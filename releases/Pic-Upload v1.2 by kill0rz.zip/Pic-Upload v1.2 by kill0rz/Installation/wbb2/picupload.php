<?php

// Konfiguration Anfang

$subordner = "Fotoalben"; //ohne / am Ende
$erlaubtegruppen = array("1","2","3");

// Konfiguration Ende

//
//

//
// Pic-Upload Script v1 by kill0rz
// �nderungen immer erlaubt, aber Copyright muss unver�ndert gelassen und auf �nderungen hingewiesen werden.
//

//
//

require('./global.php');
require('./acp/lib/class_parse.php');
require('./acp/lib/class_parsecode.php');	
require('./acp/lib/options.inc.php');	

$albenurl = $url2board . "/" . $subordner . "/";
$error = "";	

function inarray($array1,$array2){
	$istdrin = false;	
	foreach($array1 as $a1){		
		foreach($array2 as $a2){
			if($a1 == $a2){
				$istdrin = true;
			}
		}		
	}
	return $istdrin;
}

function makeindex($pfad){
	$datei = fopen($pfad."index.php","w");
	fwrite($datei,"");
	fclose($datei);
}

$loggedin = false;
if($wbbuserdata['userid'] != "0"){
	if(inarray($erlaubtegruppen,$wbbuserdata['groupids'])){ 
		$loggedin = true;
	}
}

if($loggedin){
	$done = false;		
	if(isset($_POST['newdir']) and trim($_POST['newdir']) != ''){
		$ordner = trim($_POST['newdir']);
	}else{
		$ordner = trim($_POST['ordner']);
	}
	
	if($ordner == ""){
		$ordner = "default";
	}
	
	$ersetzen = array( '�' => 'ae', '�' => 'oe', '�' => 'ue', '�' => 'ss', ' ' => '_', '\\' => '-', '/' => '-', "http://" => "", "http" => "", "//" => "", ":" => "" );
	$ordner = strtr(strtolower($ordner), $ersetzen);
	if(isset($_POST['sent']) and $_POST['sent'] == 1){	
		$links = $_POST['links'];
		
		//Local-Upload Felder
		
		for($feld = 1; $feld < 6; $feld++){
		
			if(isset($_FILES["file".$feld]) and $_FILES["file".$feld]['size'] > 0 and substr( strtolower( $_FILES["file".$feld]['name'] ), -5 ) == '.jpeg' || substr( strtolower( $_FILES["file".$feld]['name'] ), -4 ) == '.jpg' || substr( strtolower( $_FILES["file".$feld]['name'] ), -4 ) == '.gif' || substr( strtolower( $_FILES["file".$feld]['name'] ), -4 ) == '.bmp' || substr( strtolower( $_FILES["file".$feld]['name'] ), -4 ) == '.png'){
				if(!is_dir($subordner."/".$wbbuserdata['userid'])){
					mkdir($subordner."/".$wbbuserdata['userid'], 0777);
				}
				if(!is_dir($subordner)){
					mkdir($subordner, 0777);
				}
				if(!is_dir($subordner."/".$wbbuserdata['userid']."/".$ordner)){
					mkdir($subordner."/".$wbbuserdata['userid']."/".$ordner, 0777);
				}
				makeindex($subordner."/".$wbbuserdata['userid']."/".$ordner."/");
				makeindex($subordner."/".$wbbuserdata['userid']."/");
				makeindex($subordner."/");
				$umaskold = umask( 0 );
				$DateiName = strtr(strtolower($_FILES["file".$feld]['name']), $ersetzen);
				if(file_exists($subordner."/".$wbbuserdata['userid']."/".$ordner."/".$DateiName)){
					sleep(1);
					$DateiName = time().$DateiName;
				}
				if(@move_uploaded_file($_FILES["file".$feld]['tmp_name'], $subordner."/".$wbbuserdata['userid']."/".$ordner."/".$DateiName)){
					$links .= "[IMG]".$albenurl.$wbbuserdata['userid']."/".$ordner."/".$DateiName."[/IMG]\n";
					@chmod( $DateiName, 0755 );
				}else{
					$error .= "Error 1<br>";
				}
				@umask( $umaskold );
				$done = true;
			}
			
		}
		
		//URL-Felder
		
		for($feld = 1; $feld < 6; $feld++){

			if(trim($_POST["url".$feld]) != "http://example.com/pic.jpg" and isset($_POST["url".$feld]) and substr( strtolower( $_POST["url".$feld] ), -5 ) == '.jpeg' || substr( strtolower( $_POST["url".$feld] ), -4 ) == '.jpg' || substr( strtolower( $_POST["url".$feld] ), -4 ) == '.gif' || substr( strtolower( $_POST["url".$feld] ), -4 ) == '.bmp' || substr( strtolower( $_POST["url".$feld] ), -4 ) == '.png'){
			$stripped = trim($_POST["url".$feld]);
			$stripped = strip_tags($stripped);
			$wegarray = "<,>,%3E,alert(,http://,ftp://,sftp://,https://,http%3A%2F%2,https%3A%2F%2,ftp%3A%2F%2,sftp%3A%2F%2,String.fromCharCode,(,),',".'",;,<?,<?php,?>';
			$wegarray = explode(',',$wegarray);
			for($j = 1; $j < count($wegarray); $j++){
				$wegarray[$j] = trim($wegarray[$j]);
			}			
			$stripped = str_replace($wegarray, "", $stripped);
			$checker = 'http://';
			$checker_len = strlen($checker);
			$short_string = substr($stripped, 0, $checker_len);
			if($short_string != $checker){
				$stripped = "http://" . $stripped;
			}
			
			if(!is_dir($subordner."/".$wbbuserdata['userid'])){
				mkdir($subordner."/".$wbbuserdata['userid'], 0777);
			}
			if(!is_dir($subordner."/".$wbbuserdata['userid']."/".$ordner)){
				mkdir($subordner."/".$wbbuserdata['userid']."/".$ordner, 0777);
			}
			makeindex($subordner."/".$wbbuserdata['userid']."/".$ordner."/");
			makeindex($subordner."/".$wbbuserdata['userid']."/");
			$umaskold = umask( 0 );
			$stranfang = strripos($stripped,"/");
			$DateiName = strtr(strtolower(substr($stripped,$stranfang+1)), $ersetzen);
			if(file_exists($subordner."/".$wbbuserdata['userid']."/".$ordner."/".$DateiName)){
				sleep(1);
				$DateiName = time().$DateiName;
			}
			if(@copy($stripped, $subordner."/".$wbbuserdata['userid']."/".$ordner."/".$DateiName)){
				$links .= "[IMG]".$albenurl.$wbbuserdata['userid']."/".$ordner."/".$DateiName."[/IMG]\n";
				@chmod( $DateiName, 0755 );
			}else{
				$error .= "Error 2<br>";
			}
			@umask( $umaskold );
			$done = true;
		}
				
		}
		
		
		if($links != ""){
			$ausgabe = "<textarea rows=10 cols=150>".$links."</textarea>";
		}
		if(!$done){
			$error .= "Falsches Dateiformat oder kein g�ltiger Ordner!<br>";
		}
	}
		
		$ausgabelinks = $links;
			$verzeichnishandle = $subordner."/".$wbbuserdata['userid'];
			if(is_dir($verzeichnishandle)){				
				$inhalt = scandir($verzeichnishandle);
				$options = "<option>default</option>";
				foreach($inhalt as $verzeichnis){
					if($verzeichnis != '.' and $verzeichnis != '..' and $verzeichnis != 'index.php' and $verzeichnis != 'default'){
						if(isset($_POST['ordner']) and trim($_POST['ordner']) ==$verzeichnis){
							$selected = " selected";
						}else{
							$selected = "";
						}
						$options .= "<option{$selected}>".$verzeichnis."</option>";
					}
				}			
			}else{
				$options .= "<option>default</option>";
			}
			
		$folders = '';
		if(is_dir($verzeichnishandle)){
			$folder = scandir($verzeichnishandle);
			if(count($folder) < 1){
				$folders = "Noch keine Vorhanden!";
			}else{
				foreach($folder as $f){
					if($f != '.' and $f != '..' and $f != 'index.php'){
						$folders .= "<a href='?folder=".$f."#inhalt'>".$f."</a> | ";
					}
				}
			}
		}else{
			$folders = "Noch keine vorhanden";
		}
		$links = '';
		if(isset($_GET['folder']) and $_GET['folder'] != ''){
			if(is_dir($verzeichnishandle."/".$_GET['folder'])){
				$folder = scandir($verzeichnishandle."/".$_GET['folder']);
				foreach($folder as $f){
					if($f != '.' and $f != '..' and $f != 'index.php'){
						$links .= "[IMG]".$url2board."/".$verzeichnishandle."/".$_GET['folder']."/".$f."[/IMG]\n";
					}
				}
				$unterelinks = "<textarea rows=10 cols=150>".$links."</textarea>";
			}else{
				$error .= "Error 3";
			}
		}
}else{
	echo "<meta http-equiv='refresh' content='0,index.php' />";
}
eval("\$tpl->output(\"".$tpl->get("picupload2")."\");");