<?php

//
//

//
// Pic-Upload Script v3.0 by kill0rz
//

//
//

// Konfiguration Anfang

// Wo sollen die Bilder gespeichert werden?
$subordner = "Fotoalben"; //ohne / am Ende

// IDs der Benutzergruppen, die auf den Hack zugreifen dürfen
$erlaubtegruppen = array("1", "2", "3");

// ID des Boards, in das alle Bilder gepostet werden sollen. 0 zum Deaktivieren
$fotoalben_board_id = 1;

// Wenn du die XY Megashoutbox 1.3 installiert hast, kannst du hier die Freigabe zum Zufallsbild an und ausschalten.
$use_randompic = true;

// Konfiguration Ende